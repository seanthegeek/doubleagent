# Project memory

- Tests run with `npm test`.
