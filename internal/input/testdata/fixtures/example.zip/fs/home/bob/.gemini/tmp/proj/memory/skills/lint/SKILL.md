Run the linter before committing.
