class Function: pass
